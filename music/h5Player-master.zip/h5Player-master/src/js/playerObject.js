{
	domId:"",
	dom:"".
	songList:[
		{
			name:"",
			src:"",
			lrc:""
		},
		{

		}
	],
	palyMode:,
	playState:,
	deviceType:,
	volume:,
	nowSong:{
		source:songList[i],
		lrcFactory:,
	}
}

function(){

}

